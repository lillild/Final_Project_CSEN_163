THEME COLORS:
#6d1a36
#f7b7a3
#ffe9d6
#f5cebc
#f1eaf0
#666
#333

FONT:
'Montserrat', sans-serif

Navigation:
Login -> Landing -> (first time cooking)Step1[add ingredients] -> Step2[toggle for cooking utencils]
-> Get AI Recipes -> (done first time cooking goto homepage) Home -> (can goto) Recipe, impact, help, my account, cooknow[the step cycles again]
(Add anything else u guys wanna include)

MISSING PARTS:
1. Step1
2. Recipe generated page (after step2)
3. Recipe page from home
4. Impact page from home
5. Help page from home
6. Account page from home
7. Cook now (last step: simply link to step 1)
